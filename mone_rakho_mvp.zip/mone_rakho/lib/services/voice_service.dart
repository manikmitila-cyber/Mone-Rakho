import 'package:speech_to_text/speech_to_text.dart' as stt;

class VoiceService {
  VoiceService();

  final stt.SpeechToText _speech = stt.SpeechToText();
  bool _ready = false;
  void Function(String text, bool isFinal)? _onText;
  void Function()? _onStop;
  void Function(String message)? _onError;

  bool get isListening => _speech.isListening;

  Future<bool> start({
    required String lang,
    required void Function(String text, bool isFinal) onText,
    required void Function() onStop,
    required void Function(String message) onError,
  }) async {
    _onText = onText;
    _onStop = onStop;
    _onError = onError;

    if (!_ready) {
      _ready = await _speech.initialize(
        onStatus: (s) {
          if (s == 'done' || s == 'notListening') _onStop?.call();
        },
        onError: (e) => _onError?.call(e.errorMsg),
      );
    }
    if (!_ready) return false;

    String? localeId;
    try {
      final locales = await _speech.locales();
      final prefix = lang == 'bn' ? 'bn' : 'en';
      final match = locales
          .where((l) => l.localeId.toLowerCase().startsWith(prefix))
          .toList();
      if (match.isNotEmpty) {
        final pref = lang == 'bn' ? 'bd' : 'us';
        localeId = match
            .firstWhere(
              (l) => l.localeId.toLowerCase().contains(pref),
              orElse: () => match.first,
            )
            .localeId;
      } else if (lang == 'bn') {
        localeId = 'bn_BD';
      }
    } catch (_) {}

    await _speech.listen(
      onResult: (r) => _onText?.call(r.recognizedWords, r.finalResult),
      localeId: localeId,
      listenFor: const Duration(minutes: 2),
      pauseFor: const Duration(seconds: 5),
    );
    return true;
  }

  Future<void> stop() async {
    try {
      await _speech.stop();
    } catch (_) {}
  }
}
