import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;
import '../models/memory.dart';

class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();

  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  bool _ready = false;

  static const _channelId = 'mone_rakho_reminders';

  Future<void> init() async {
    if (_ready) return;
    tzdata.initializeTimeZones();
    try {
      final name = await FlutterTimezone.getLocalTimezone();
      tz.setLocalLocation(tz.getLocation(name));
    } catch (_) {
      tz.setLocalLocation(tz.getLocation('Asia/Dhaka'));
    }

    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    await _plugin.initialize(const InitializationSettings(android: android));

    final impl = _plugin.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    await impl?.createNotificationChannel(const AndroidNotificationChannel(
      _channelId,
      'রিমাইন্ডার',
      description: 'স্মৃতির রিমাইন্ডার নোটিফিকেশন',
      importance: Importance.max,
    ));
    _ready = true;
  }

  Future<bool> requestPermissions() async {
    final impl = _plugin.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    final granted = await impl?.requestNotificationsPermission();
    return granted ?? true;
  }

  int _idFor(String uuid) {
    var h = 0;
    for (final c in uuid.codeUnits) {
      h = (h * 31 + c) & 0x7fffffff;
    }
    return h;
  }

  NotificationDetails _details(String body) => NotificationDetails(
        android: AndroidNotificationDetails(
          _channelId,
          'রিমাইন্ডার',
          channelDescription: 'স্মৃতির রিমাইন্ডার নোটিফিকেশন',
          importance: Importance.max,
          priority: Priority.high,
          category: AndroidNotificationCategory.reminder,
          styleInformation: BigTextStyleInformation(body),
        ),
      );

  Future<void> _zoned(
    int id,
    String title,
    String body,
    tz.TZDateTime when, {
    DateTimeComponents? match,
  }) async {
    try {
      await _plugin.zonedSchedule(
        id,
        title,
        body,
        when,
        _details(body),
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
        matchDateTimeComponents: match,
      );
    } on PlatformException {
      await _plugin.zonedSchedule(
        id,
        title,
        body,
        when,
        _details(body),
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
        matchDateTimeComponents: match,
      );
    }
  }

  DateTime _advance(DateTime d, String repeat) {
    switch (repeat) {
      case 'daily':
        return DateTime(d.year, d.month, d.day + 1, d.hour, d.minute);
      case 'weekly':
        return DateTime(d.year, d.month, d.day + 7, d.hour, d.minute);
      case 'monthly':
        return DateTime(d.year, d.month + 1, d.day, d.hour, d.minute);
      default:
        return d;
    }
  }

  Future<void> schedule(Memory m) async {
    await init();
    final id = _idFor(m.id);
    await _plugin.cancel(id);
    if (m.reminderDate == null || m.isDone) return;

    DateTimeComponents? match;
    switch (m.repeat) {
      case 'daily':
        match = DateTimeComponents.time;
        break;
      case 'weekly':
        match = DateTimeComponents.dayOfWeekAndTime;
        break;
      case 'monthly':
        match = DateTimeComponents.dayOfMonthAndTime;
        break;
    }

    var when = m.reminderDate!;
    final now = DateTime.now();
    if (match == null) {
      if (!when.isAfter(now)) return;
    } else {
      var guard = 0;
      while (!when.isAfter(now) && guard < 800) {
        when = _advance(when, m.repeat);
        guard++;
      }
    }

    final body = m.description.trim().isEmpty ? 'মনে রাখার সময় হয়েছে' : m.description;
    await _zoned(
      id,
      m.title,
      body,
      tz.TZDateTime.from(when, tz.local),
      match: match,
    );
  }

  Future<void> cancel(String memoryId) async {
    await init();
    await _plugin.cancel(_idFor(memoryId));
  }

  Future<void> rescheduleAll(List<Memory> memories) async {
    for (final m in memories) {
      if (m.reminderDate != null && !m.isDone) {
        try {
          await schedule(m);
        } catch (_) {}
      }
    }
  }

  Future<void> scheduleTest() async {
    await init();
    final when = tz.TZDateTime.now(tz.local).add(const Duration(seconds: 10));
    await _zoned(
      999999,
      'টেস্ট রিমাইন্ডার ✅',
      'নোটিফিকেশন ঠিকমতো কাজ করছে!',
      when,
    );
  }
}
