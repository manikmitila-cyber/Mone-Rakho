import 'package:flutter/services.dart';
import 'package:local_auth/local_auth.dart';

class LockService {
  LockService._();
  static final LockService instance = LockService._();

  final LocalAuthentication _auth = LocalAuthentication();

  Future<bool> isSupported() async {
    try {
      return await _auth.isDeviceSupported();
    } catch (_) {
      return false;
    }
  }

  /// true = আনলক। ফোনে স্ক্রিন লক/ফিঙ্গারপ্রিন্ট না থাকলে ঢুকতে দেয়,
  /// যাতে ব্যবহারকারী নিজের অ্যাপে আটকে না যান।
  Future<bool> authenticate(String reason) async {
    try {
      return await _auth.authenticate(
        localizedReason: reason,
        options: const AuthenticationOptions(stickyAuth: true),
      );
    } on PlatformException catch (e) {
      final code = e.code.toLowerCase();
      if (code.contains('notavailable') ||
          code.contains('notenrolled') ||
          code.contains('passcodenotset')) {
        return true;
      }
      return false;
    } catch (_) {
      return false;
    }
  }
}
