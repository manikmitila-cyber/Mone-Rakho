import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SettingsService extends ChangeNotifier {
  SettingsService._();
  static final SettingsService instance = SettingsService._();

  static const defaultClaudeModel = 'claude-haiku-5-5';
  static const defaultGeminiModel = 'gemini-2.5-flash';

  final FlutterSecureStorage _secure = const FlutterSecureStorage();
  SharedPreferences? _prefs;

  ThemeMode themeMode = ThemeMode.system;
  bool lockEnabled = false;
  String provider = 'gemini'; // gemini | claude
  String voiceLang = 'bn'; // bn | en
  String claudeModel = defaultClaudeModel;
  String geminiModel = defaultGeminiModel;
  final Map<String, String> _keys = {};

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    _prefs = p;
    themeMode = _modeFrom(p.getString('themeMode'));
    lockEnabled = p.getBool('lockEnabled') ?? false;
    provider = p.getString('provider') ?? 'gemini';
    voiceLang = p.getString('voiceLang') ?? 'bn';
    claudeModel = p.getString('claudeModel') ?? defaultClaudeModel;
    geminiModel = p.getString('geminiModel') ?? defaultGeminiModel;
    for (final name in ['claude', 'gemini']) {
      try {
        _keys[name] = await _secure.read(key: 'key_$name') ?? '';
      } catch (_) {
        _keys[name] = '';
      }
    }
    notifyListeners();
  }

  ThemeMode _modeFrom(String? v) {
    switch (v) {
      case 'light':
        return ThemeMode.light;
      case 'dark':
        return ThemeMode.dark;
      default:
        return ThemeMode.system;
    }
  }

  String keyFor(String p) => _keys[p] ?? '';
  String get apiKey => keyFor(provider);
  String get model => provider == 'claude' ? claudeModel : geminiModel;
  bool get aiReady => apiKey.trim().isNotEmpty;

  Future<void> setThemeMode(ThemeMode m) async {
    themeMode = m;
    await _prefs?.setString('themeMode', m.name);
    notifyListeners();
  }

  Future<void> setLock(bool v) async {
    lockEnabled = v;
    await _prefs?.setBool('lockEnabled', v);
    notifyListeners();
  }

  Future<void> setVoiceLang(String v) async {
    voiceLang = v;
    await _prefs?.setString('voiceLang', v);
    notifyListeners();
  }

  Future<void> setProvider(String v) async {
    provider = v;
    await _prefs?.setString('provider', v);
    notifyListeners();
  }

  Future<void> setModel(String providerName, String value) async {
    final v = value.trim();
    if (providerName == 'claude') {
      claudeModel = v.isEmpty ? defaultClaudeModel : v;
      await _prefs?.setString('claudeModel', claudeModel);
    } else {
      geminiModel = v.isEmpty ? defaultGeminiModel : v;
      await _prefs?.setString('geminiModel', geminiModel);
    }
    notifyListeners();
  }

  Future<void> setApiKey(String providerName, String value) async {
    final v = value.trim();
    _keys[providerName] = v;
    try {
      await _secure.write(key: 'key_$providerName', value: v);
    } catch (_) {}
    notifyListeners();
  }
}
