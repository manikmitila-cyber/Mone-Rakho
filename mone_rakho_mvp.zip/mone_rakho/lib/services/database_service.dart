import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import '../models/memory.dart';

class DatabaseService {
  DatabaseService._();
  static final DatabaseService instance = DatabaseService._();

  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    _db = await _open();
    return _db!;
  }

  Future<Database> _open() async {
    final dbPath = join(await getDatabasesPath(), 'mone_rakho.db');
    return openDatabase(
      dbPath,
      version: 2,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE memories(
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            description TEXT NOT NULL,
            category TEXT NOT NULL,
            reminderDate INTEGER,
            createdAt INTEGER NOT NULL,
            repeatRule TEXT NOT NULL DEFAULT 'none',
            tags TEXT NOT NULL DEFAULT '[]',
            imagePath TEXT,
            isDone INTEGER NOT NULL DEFAULT 0,
            isPinned INTEGER NOT NULL DEFAULT 0
          )
        ''');
      },
      onUpgrade: (db, oldVersion, newVersion) async {
        if (oldVersion < 2) {
          await db.execute(
              "ALTER TABLE memories ADD COLUMN repeatRule TEXT NOT NULL DEFAULT 'none'");
          await db.execute(
              "ALTER TABLE memories ADD COLUMN tags TEXT NOT NULL DEFAULT '[]'");
          await db.execute('ALTER TABLE memories ADD COLUMN imagePath TEXT');
          await db.execute(
              'ALTER TABLE memories ADD COLUMN isDone INTEGER NOT NULL DEFAULT 0');
          await db.execute(
              'ALTER TABLE memories ADD COLUMN isPinned INTEGER NOT NULL DEFAULT 0');
        }
      },
    );
  }

  Future<void> insertMemory(Memory memory) async {
    final db = await database;
    await db.insert(
      'memories',
      memory.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> updateMemory(Memory memory) async {
    final db = await database;
    await db.update(
      'memories',
      memory.toMap(),
      where: 'id = ?',
      whereArgs: [memory.id],
    );
  }

  Future<List<Memory>> getMemories() async {
    final db = await database;
    final rows = await db.query('memories', orderBy: 'createdAt DESC');
    return rows.map(Memory.fromMap).toList();
  }

  Future<void> deleteMemory(String id) async {
    final db = await database;
    await db.delete('memories', where: 'id = ?', whereArgs: [id]);
  }
}
