import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import '../models/memory.dart';

class DatabaseService {
  DatabaseService._();
  static final DatabaseService instance = DatabaseService._();

  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    _db = await _open();
    return _db!;
  }

  Future<Database> _open() async {
    final dbPath = join(await getDatabasesPath(), 'mone_rakho.db');
    return openDatabase(
      dbPath,
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE memories(
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            description TEXT NOT NULL,
            category TEXT NOT NULL,
            reminderDate INTEGER,
            createdAt INTEGER NOT NULL
          )
        ''');
      },
    );
  }

  Future<void> insertMemory(Memory memory) async {
    final db = await database;
    await db.insert(
      'memories',
      memory.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<List<Memory>> getMemories() async {
    final db = await database;
    final rows = await db.query(
      'memories',
      orderBy: 'createdAt DESC',
    );
    return rows.map(Memory.fromMap).toList();
  }

  Future<void> deleteMemory(String id) async {
    final db = await database;
    await db.delete('memories', where: 'id = ?', whereArgs: [id]);
  }
}
