import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';

import '../models/categories.dart';
import '../models/memory.dart';
import 'settings_service.dart';

class AiException implements Exception {
  final String message;
  AiException(this.message);
  @override
  String toString() => message;
}

class AiResult {
  final String title;
  final String description;
  final String category;
  final List<String> tags;
  final DateTime? reminder;
  final String repeat;

  const AiResult({
    required this.title,
    required this.description,
    required this.category,
    required this.tags,
    required this.reminder,
    required this.repeat,
  });
}

class AiService {
  AiService._();
  static final AiService instance = AiService._();

  SettingsService get _s => SettingsService.instance;

  static const _organizeSystem = '''
তুমি "মনে রাখো" অ্যাপের স্মার্ট সহকারী। ব্যবহারকারী বাংলা, ইংরেজি বা মিশ্র ভাষায় (অথবা ছবি দিয়ে) কিছু মনে রাখতে বলে। তোমার কাজ সেটা গুছিয়ে শুধু একটি JSON অবজেক্ট ফেরত দেওয়া। কোনো ব্যাখ্যা, মার্কডাউন বা কোড ব্লক দেবে না।

JSON ফরম্যাট:
{"title": "...", "description": "...", "category": "...", "tags": ["..."], "reminder": "YYYY-MM-DDTHH:MM" অথবা null, "repeat": "none"}

নিয়ম:
- title: সর্বোচ্চ ৬০ অক্ষরের ছোট পরিষ্কার শিরোনাম, বাংলায়।
- description: গুরুত্বপূর্ণ সব তথ্য (নাম, টাকার অঙ্ক, তারিখ, ঠিকানা, নম্বর ইত্যাদি) হুবহু ঠিক রেখে গুছিয়ে লেখো। ছবিতে লেখা থাকলে পড়ে এখানে লেখো। কিছু বানিয়ে লিখবে না।
- category: ঠিক একটি — General, Reminder, Money, Document, Things, Health
- tags: ০ থেকে ৪টি ছোট ট্যাগ।
- reminder: ব্যবহারকারী সময় বা তারিখের কথা বললে (যেমন "কাল বিকেলে", "আজ সন্ধ্যায়") এখনকার তারিখ-সময় ধরে হিসাব করে স্থানীয় সময়ে দাও। সময় অস্পষ্ট হলে সকাল=09:00, দুপুর=13:00, বিকাল=16:00, সন্ধ্যা=18:00, রাত=21:00 ধরো। সময়ের কথা না থাকলে null।
- repeat: "প্রতিদিন" হলে daily, "প্রতি সপ্তাহে" হলে weekly, "প্রতি মাসে" হলে monthly, না হলে none।
''';

  static const _askSystem = '''
তুমি "মনে রাখো" অ্যাপের সহকারী। নিচে ব্যবহারকারীর সংরক্ষিত স্মৃতির তালিকা দেওয়া আছে। শুধু এই তথ্য থেকে প্রশ্নের উত্তর দাও। উত্তর হবে বাংলায়, ছোট ও পরিষ্কার। তথ্য না থাকলে স্পষ্ট বলো যে স্মৃতিতে নেই। আন্দাজে কিছু বানাবে না।
''';

  static const _summarySystem = '''
তুমি "মনে রাখো" অ্যাপের সহকারী। ব্যবহারকারীর বাকি কাজ ও রিমাইন্ডার থেকে আজকের একটি ছোট, বন্ধুত্বপূর্ণ সারসংক্ষেপ লেখো। বাংলায়, সর্বোচ্চ ৬ লাইন। সবচেয়ে জরুরি জিনিস আগে বলো। তালিকায় না থাকা কিছু বানাবে না।
''';

  String _now() => DateFormat('yyyy-MM-dd HH:mm, EEEE').format(DateTime.now());

  String _mimeOf(String path) {
    final p = path.toLowerCase();
    if (p.endsWith('.png')) return 'image/png';
    if (p.endsWith('.webp')) return 'image/webp';
    return 'image/jpeg';
  }

  // ---------- public API ----------

  Future<AiResult> organize({String? text, String? imagePath}) async {
    final t = (text ?? '').trim();
    final prompt = 'এখনকার তারিখ-সময়: ${_now()}\n\n'
        'ব্যবহারকারীর কথা: ${t.isEmpty ? "(শুধু ছবি দেওয়া হয়েছে)" : t}';
    final raw = await _complete(
      system: _organizeSystem,
      prompt: prompt,
      imagePath: imagePath,
      json: true,
    );
    return _parseOrganize(raw);
  }

  Future<String> ask(String question, List<Memory> memories) async {
    final prompt = 'এখনকার তারিখ-সময়: ${_now()}\n\n'
        'স্মৃতির তালিকা:\n${_context(memories, 150)}\n\n'
        'প্রশ্ন: $question';
    return (await _complete(system: _askSystem, prompt: prompt)).trim();
  }

  Future<String> summarize(List<Memory> memories) async {
    final now = DateTime.now();
    final limit = now.add(const Duration(days: 7));
    final relevant = memories.where((m) {
      if (m.isDone) return false;
      if (m.isPinned) return true;
      final r = m.reminderDate;
      if (r == null) return false;
      if (m.repeat != 'none') return true;
      return r.isBefore(limit);
    }).toList();
    if (relevant.isEmpty) {
      return 'আজ কোনো বাকি কাজ বা রিমাইন্ডার নেই। দিনটা ভালো কাটুক! 🌿';
    }
    final prompt = 'এখনকার তারিখ-সময়: ${_now()}\n\n'
        'বাকি কাজ ও রিমাইন্ডার:\n${_context(relevant, 60)}';
    return (await _complete(system: _summarySystem, prompt: prompt)).trim();
  }

  Future<String> ping() async {
    return (await _complete(
      system: 'সংক্ষেপে বাংলায় উত্তর দাও।',
      prompt: 'শুধু লেখো: AI ঠিকমতো কাজ করছে',
    ))
        .trim();
  }

  // ---------- helpers ----------

  String _context(List<Memory> list, int max) {
    final df = DateFormat('yyyy-MM-dd HH:mm');
    final items = list.take(max);
    final buf = StringBuffer();
    for (final m in items) {
      var desc = m.description.replaceAll('\n', ' ');
      if (desc.length > 300) desc = desc.substring(0, 300);
      buf.write('- [${DateFormat('yyyy-MM-dd').format(m.createdAt)}] '
          '[${categoryLabel(m.category)}] ${m.title}');
      if (desc.isNotEmpty) buf.write(': $desc');
      if (m.tags.isNotEmpty) buf.write(' (ট্যাগ: ${m.tags.join(", ")})');
      if (m.reminderDate != null) {
        buf.write(' (রিমাইন্ডার: ${df.format(m.reminderDate!)}');
        if (m.repeat != 'none') buf.write(', ${repeatLabels[m.repeat]}');
        buf.write(')');
      }
      if (m.isDone) buf.write(' (সম্পন্ন)');
      buf.writeln();
    }
    return buf.toString();
  }

  AiResult _parseOrganize(String raw) {
    final start = raw.indexOf('{');
    final end = raw.lastIndexOf('}');
    if (start < 0 || end <= start) {
      throw AiException('AI-এর উত্তর বোঝা যায়নি। আবার চেষ্টা করুন।');
    }
    Map<String, dynamic> map;
    try {
      map = jsonDecode(raw.substring(start, end + 1)) as Map<String, dynamic>;
    } catch (_) {
      throw AiException('AI-এর উত্তর বোঝা যায়নি। আবার চেষ্টা করুন।');
    }

    var category = (map['category'] ?? 'General').toString();
    if (!categoryLabels.containsKey(category)) category = 'General';

    var repeat = (map['repeat'] ?? 'none').toString();
    if (!repeatLabels.containsKey(repeat)) repeat = 'none';

    final tags = <String>[];
    final rawTags = map['tags'];
    if (rawTags is List) {
      for (final t in rawTags) {
        final s = t.toString().trim();
        if (s.isNotEmpty) tags.add(s);
      }
    }

    DateTime? reminder;
    final r = map['reminder'];
    if (r != null && r.toString().isNotEmpty && r.toString() != 'null') {
      reminder = DateTime.tryParse(r.toString());
    }

    return AiResult(
      title: (map['title'] ?? '').toString().trim(),
      description: (map['description'] ?? '').toString().trim(),
      category: category,
      tags: tags,
      reminder: reminder,
      repeat: repeat,
    );
  }

  Future<String> _complete({
    required String system,
    required String prompt,
    String? imagePath,
    bool json = false,
  }) async {
    if (!_s.aiReady) {
      throw AiException('আগে সেটিংসে AI-এর API key দিন।');
    }
    String? b64;
    var mime = 'image/jpeg';
    if (imagePath != null) {
      final f = File(imagePath);
      if (await f.exists()) {
        b64 = base64Encode(await f.readAsBytes());
        mime = _mimeOf(imagePath);
      }
    }
    try {
      if (_s.provider == 'claude') {
        return await _claude(system, prompt, b64, mime);
      }
      return await _gemini(system, prompt, b64, mime, json);
    } on SocketException {
      throw AiException('ইন্টারনেট সংযোগ নেই।');
    } on TimeoutException {
      throw AiException('AI-এর উত্তর আসতে দেরি হচ্ছে। আবার চেষ্টা করুন।');
    } on http.ClientException {
      throw AiException('ইন্টারনেট সংযোগে সমস্যা হয়েছে।');
    }
  }

  Future<String> _claude(
      String system, String prompt, String? b64, String mime) async {
    final content = <Map<String, dynamic>>[
      if (b64 != null)
        {
          'type': 'image',
          'source': {'type': 'base64', 'media_type': mime, 'data': b64},
        },
      {'type': 'text', 'text': prompt},
    ];
    final res = await http
        .post(
          Uri.parse('https://api.anthropic.com/v1/messages'),
          headers: {
            'content-type': 'application/json',
            'x-api-key': _s.apiKey.trim(),
            'anthropic-version': '2023-06-01',
          },
          body: jsonEncode({
            'model': _s.model.trim(),
            'max_tokens': 1500,
            'system': system,
            'messages': [
              {'role': 'user', 'content': content},
            ],
          }),
        )
        .timeout(const Duration(seconds: 60));
    final data = _decode(res);
    final blocks = (data['content'] as List?) ?? [];
    final text = blocks
        .whereType<Map>()
        .where((b) => b['type'] == 'text')
        .map((b) => b['text'].toString())
        .join('\n');
    if (text.trim().isEmpty) throw AiException('AI কোনো উত্তর দেয়নি।');
    return text;
  }

  Future<String> _gemini(String system, String prompt, String? b64,
      String mime, bool json) async {
    final uri = Uri.parse(
        'https://generativelanguage.googleapis.com/v1beta/models/${_s.model.trim()}:generateContent');
    final res = await http
        .post(
          uri,
          headers: {
            'content-type': 'application/json',
            'x-goog-api-key': _s.apiKey.trim(),
          },
          body: jsonEncode({
            'systemInstruction': {
              'parts': [
                {'text': system},
              ],
            },
            'contents': [
              {
                'role': 'user',
                'parts': [
                  {'text': prompt},
                  if (b64 != null)
                    {
                      'inline_data': {'mime_type': mime, 'data': b64},
                    },
                ],
              },
            ],
            'generationConfig': {
              'temperature': 0.2,
              if (json) 'responseMimeType': 'application/json',
            },
          }),
        )
        .timeout(const Duration(seconds: 60));
    final data = _decode(res);
    final cands = (data['candidates'] as List?) ?? [];
    if (cands.isEmpty) throw AiException('AI কোনো উত্তর দেয়নি।');
    final content = (cands.first as Map)['content'];
    final parts = (content is Map ? content['parts'] as List? : null) ?? [];
    final text = parts
        .whereType<Map>()
        .map((p) => (p['text'] ?? '').toString())
        .join('\n');
    if (text.trim().isEmpty) throw AiException('AI কোনো উত্তর দেয়নি।');
    return text;
  }

  Map<String, dynamic> _decode(http.Response res) {
    final body = utf8.decode(res.bodyBytes);
    if (res.statusCode >= 200 && res.statusCode < 300) {
      return jsonDecode(body) as Map<String, dynamic>;
    }
    var detail = '';
    try {
      final j = jsonDecode(body);
      final e = j is Map ? j['error'] : null;
      detail = (e is Map ? (e['message'] ?? '') : (e ?? '')).toString();
    } catch (_) {}

    if (res.statusCode == 401 ||
        res.statusCode == 403 ||
        detail.toLowerCase().contains('api key')) {
      throw AiException('API key ঠিক নেই বা অনুমতি নেই। সেটিংসে যাচাই করুন।');
    }
    if (res.statusCode == 429) {
      throw AiException('AI-এর ব্যবহারের সীমা পেরিয়ে গেছে। একটু পরে আবার চেষ্টা করুন।');
    }
    if (res.statusCode == 404) {
      throw AiException('মডেলের নাম ঠিক নেই। সেটিংসে মডেলের নাম যাচাই করুন।');
    }
    throw AiException('AI ত্রুটি (${res.statusCode}) $detail');
  }
}
