import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'theme/app_theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MoneRakhoApp());
}

class MoneRakhoApp extends StatelessWidget {
  const MoneRakhoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'মনে রাখো',
      theme: AppTheme.lightTheme,
      home: const HomeScreen(),
    );
  }
}
