import 'package:flutter/material.dart';
import 'screens/app_gate.dart';
import 'services/notification_service.dart';
import 'services/settings_service.dart';
import 'theme/app_theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SettingsService.instance.load();
  try {
    await NotificationService.instance.init();
  } catch (_) {}
  runApp(const MoneRakhoApp());
}

class MoneRakhoApp extends StatelessWidget {
  const MoneRakhoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: SettingsService.instance,
      builder: (context, _) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'মনে রাখো',
        theme: AppTheme.lightTheme,
        darkTheme: AppTheme.darkTheme,
        themeMode: SettingsService.instance.themeMode,
        home: const AppGate(),
      ),
    );
  }
}
