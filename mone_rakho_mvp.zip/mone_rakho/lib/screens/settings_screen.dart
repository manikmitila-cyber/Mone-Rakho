import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import '../services/ai_service.dart';
import '../services/database_service.dart';
import '../services/lock_service.dart';
import '../services/notification_service.dart';
import '../services/settings_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final s = SettingsService.instance;
  late final TextEditingController keyController;
  late final TextEditingController modelController;
  bool showKey = false;
  bool testingAi = false;

  @override
  void initState() {
    super.initState();
    keyController = TextEditingController(text: s.apiKey);
    modelController = TextEditingController(text: s.model);
  }

  @override
  void dispose() {
    keyController.dispose();
    modelController.dispose();
    super.dispose();
  }

  void snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(msg)));
  }

  Widget section(String title) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 22, 4, 8),
        child: Text(
          title,
          style: TextStyle(
            fontWeight: FontWeight.w800,
            fontSize: 15,
            color: Theme.of(context).colorScheme.primary,
          ),
        ),
      );

  Future<void> switchProvider(String v) async {
    await s.setProvider(v);
    keyController.text = s.apiKey;
    modelController.text = s.model;
    setState(() {});
  }

  Future<void> saveAi() async {
    await s.setApiKey(s.provider, keyController.text);
    await s.setModel(s.provider, modelController.text);
    modelController.text = s.model;
    setState(() {});
    snack('সংরক্ষণ হয়েছে।');
  }

  Future<void> testAi() async {
    await saveAi();
    if (!s.aiReady) {
      snack('আগে API key দিন।');
      return;
    }
    setState(() => testingAi = true);
    try {
      final r = await AiService.instance.ping();
      snack('✅ $r');
    } on AiException catch (e) {
      snack(e.message);
    } finally {
      if (mounted) setState(() => testingAi = false);
    }
  }

  Future<void> toggleLock(bool v) async {
    if (v) {
      if (!await LockService.instance.isSupported()) {
        snack('এই ফোনে স্ক্রিন লক বা ফিঙ্গারপ্রিন্ট সেট করা নেই। আগে ফোনের সেটিংসে সেট করুন।');
        return;
      }
      final ok = await LockService.instance
          .authenticate('অ্যাপ লক চালু করতে নিজের পরিচয় নিশ্চিত করুন');
      if (!ok) {
        snack('অ্যাপ লক চালু করা যায়নি।');
        return;
      }
    }
    await s.setLock(v);
    setState(() {});
  }

  Future<void> testNotification() async {
    try {
      final granted = await NotificationService.instance.requestPermissions();
      if (!granted) {
        snack('নোটিফিকেশনের অনুমতি দেওয়া নেই। ফোনের সেটিংস থেকে অনুমতি দিন।');
        return;
      }
      await NotificationService.instance.scheduleTest();
      snack('১০ সেকেন্ডের মধ্যে একটি নোটিফিকেশন আসবে। অ্যাপ বন্ধ করে ফোন লক করেও দেখতে পারেন।');
    } catch (e) {
      snack('টেস্ট ব্যর্থ: $e');
    }
  }

  Future<void> exportData() async {
    try {
      final list = await DatabaseService.instance.getMemories();
      final data = {
        'app': 'mone_rakho',
        'exportedAt': DateTime.now().toIso8601String(),
        'memories': list.map((m) => m.toMap()).toList(),
      };
      final dir = await getTemporaryDirectory();
      final file = File(p.join(dir.path, 'mone_rakho_backup.json'));
      await file.writeAsString(const JsonEncoder.withIndent('  ').convert(data));
      await Share.shareXFiles([XFile(file.path)], text: 'মনে রাখো ব্যাকআপ');
    } catch (e) {
      snack('এক্সপোর্ট ব্যর্থ: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final isClaude = s.provider == 'claude';

    return Scaffold(
      appBar: AppBar(title: const Text('সেটিংস')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 40),
        children: [
          section('রূপ'),
          SegmentedButton<ThemeMode>(
            segments: const [
              ButtonSegment(value: ThemeMode.system, label: Text('অটো')),
              ButtonSegment(value: ThemeMode.light, label: Text('লাইট')),
              ButtonSegment(value: ThemeMode.dark, label: Text('ডার্ক')),
            ],
            selected: {s.themeMode},
            onSelectionChanged: (v) async {
              await s.setThemeMode(v.first);
              setState(() {});
            },
          ),

          section('নিরাপত্তা'),
          Card(
            child: SwitchListTile(
              value: s.lockEnabled,
              onChanged: toggleLock,
              title: const Text('অ্যাপ লক'),
              subtitle: const Text('ফিঙ্গারপ্রিন্ট, ফেস বা ফোনের PIN/প্যাটার্ন দিয়ে খুলতে হবে'),
              secondary: const Icon(Icons.lock_outline_rounded),
            ),
          ),

          section('ভয়েস'),
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'bn', label: Text('বাংলা')),
              ButtonSegment(value: 'en', label: Text('English')),
            ],
            selected: {s.voiceLang},
            onSelectionChanged: (v) async {
              await s.setVoiceLang(v.first);
              setState(() {});
            },
          ),

          section('AI সেটিংস'),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SegmentedButton<String>(
                    segments: const [
                      ButtonSegment(value: 'gemini', label: Text('Gemini')),
                      ButtonSegment(value: 'claude', label: Text('Claude')),
                    ],
                    selected: {s.provider},
                    onSelectionChanged: (v) => switchProvider(v.first),
                  ),
                  const SizedBox(height: 14),
                  TextField(
                    controller: keyController,
                    obscureText: !showKey,
                    autocorrect: false,
                    enableSuggestions: false,
                    decoration: InputDecoration(
                      labelText: isClaude ? 'Claude API key' : 'Gemini API key',
                      prefixIcon: const Icon(Icons.key_rounded),
                      suffixIcon: IconButton(
                        onPressed: () => setState(() => showKey = !showKey),
                        icon: Icon(showKey
                            ? Icons.visibility_off_rounded
                            : Icons.visibility_rounded),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: modelController,
                    autocorrect: false,
                    decoration: const InputDecoration(
                      labelText: 'মডেলের নাম',
                      prefixIcon: Icon(Icons.memory_rounded),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: FilledButton(
                          onPressed: saveAi,
                          child: const Text('সংরক্ষণ'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: OutlinedButton(
                          onPressed: testingAi ? null : testAi,
                          child: Text(testingAi ? 'টেস্ট হচ্ছে...' : 'AI টেস্ট'),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text(
                    isClaude
                        ? 'key পাবেন console.anthropic.com থেকে। এটি claude.ai সাবস্ক্রিপশন থেকে আলাদা, ব্যবহার অনুযায়ী খরচ হয়।'
                        : 'key পাবেন aistudio.google.com/apikey থেকে। বিনামূল্যের সীমা থাকতে পারে।',
                    style: TextStyle(fontSize: 12.5, color: scheme.onSurfaceVariant),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'গোপনীয়তা: key শুধু এই ফোনে সুরক্ষিত স্টোরেজে থাকে। AI ব্যবহার করলে আপনার লেখা, ছবি ও (প্রশ্ন করলে) স্মৃতির লেখা নির্বাচিত AI কোম্পানির সার্ভারে যায়।',
                    style: TextStyle(fontSize: 12.5, color: scheme.onSurfaceVariant),
                  ),
                ],
              ),
            ),
          ),

          section('রিমাইন্ডার'),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  FilledButton.tonalIcon(
                    onPressed: testNotification,
                    icon: const Icon(Icons.notifications_active_rounded),
                    label: const Text('টেস্ট নোটিফিকেশন (১০ সেকেন্ড পর)'),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    'Xiaomi / Redmi / POCO ফোনে নোটিফিকেশন না এলে:\n'
                    '১. ফোন Settings → Apps → মনে রাখো → Autostart চালু করুন\n'
                    '২. একই পেজে Battery saver → No restrictions বাছুন\n'
                    '৩. Notifications → সব অনুমতি চালু রাখুন\n'
                    '৪. Recent apps-এ অ্যাপটি লক (🔒) করে রাখুন',
                    style: TextStyle(fontSize: 12.5, color: scheme.onSurfaceVariant),
                  ),
                ],
              ),
            ),
          ),

          section('ডেটা'),
          Card(
            child: ListTile(
              leading: const Icon(Icons.ios_share_rounded),
              title: const Text('সব স্মৃতি এক্সপোর্ট (JSON)'),
              subtitle: const Text('ব্যাকআপ হিসেবে Drive, WhatsApp বা অন্য কোথাও পাঠান'),
              onTap: exportData,
            ),
          ),

          const SizedBox(height: 24),
          Center(
            child: Text(
              'মনে রাখো • সংস্করণ ২.০',
              style: TextStyle(color: scheme.onSurfaceVariant, fontSize: 12.5),
            ),
          ),
        ],
      ),
    );
  }
}
