import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';

import '../models/categories.dart';
import '../models/memory.dart';
import '../services/ai_service.dart';
import '../services/database_service.dart';
import '../services/notification_service.dart';
import '../services/settings_service.dart';
import '../services/voice_service.dart';

class AddMemoryScreen extends StatefulWidget {
  final Memory? existing;
  final bool startVoice;

  const AddMemoryScreen({super.key, this.existing, this.startVoice = false});

  @override
  State<AddMemoryScreen> createState() => _AddMemoryScreenState();
}

class _AddMemoryScreenState extends State<AddMemoryScreen> {
  final rawController = TextEditingController();
  final titleController = TextEditingController();
  final descriptionController = TextEditingController();
  final tagsController = TextEditingController();
  final voice = VoiceService();

  String category = 'General';
  String repeat = 'none';
  DateTime? reminderDate;
  String? imagePath;
  bool pinned = false;
  bool listening = false;
  bool aiBusy = false;
  bool saving = false;
  String voiceBase = '';

  bool get editing => widget.existing != null;

  @override
  void initState() {
    super.initState();
    final e = widget.existing;
    if (e != null) {
      titleController.text = e.title;
      descriptionController.text = e.description;
      tagsController.text = e.tags.join(', ');
      category = e.category;
      repeat = e.repeat;
      reminderDate = e.reminderDate;
      imagePath = e.imagePath;
      pinned = e.isPinned;
    }
    if (widget.startVoice && !editing) {
      WidgetsBinding.instance.addPostFrameCallback((_) => toggleVoice());
    }
  }

  @override
  void dispose() {
    voice.stop();
    rawController.dispose();
    titleController.dispose();
    descriptionController.dispose();
    tagsController.dispose();
    super.dispose();
  }

  void snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(msg)));
  }

  // ---------- voice ----------

  Future<void> toggleVoice() async {
    if (listening) {
      await voice.stop();
      if (mounted) setState(() => listening = false);
      return;
    }
    voiceBase = rawController.text.trim();
    final ok = await voice.start(
      lang: SettingsService.instance.voiceLang,
      onText: (words, isFinal) {
        if (!mounted) return;
        final joined = voiceBase.isEmpty ? words : '$voiceBase $words';
        rawController.text = joined;
        rawController.selection =
            TextSelection.collapsed(offset: rawController.text.length);
      },
      onStop: () {
        if (mounted) setState(() => listening = false);
      },
      onError: (msg) {
        if (mounted) {
          setState(() => listening = false);
          snack('ভয়েস ত্রুটি: $msg');
        }
      },
    );
    if (!mounted) return;
    if (!ok) {
      snack('মাইক্রোফোনের অনুমতি দিন বা ফোনে স্পিচ সার্ভিস চালু আছে কিনা দেখুন।');
      return;
    }
    setState(() => listening = true);
  }

  // ---------- image ----------

  Future<void> pickImage(ImageSource source) async {
    try {
      final x = await ImagePicker().pickImage(
        source: source,
        maxWidth: 1600,
        maxHeight: 1600,
        imageQuality: 80,
      );
      if (x == null) return;
      final dir = await getApplicationDocumentsDirectory();
      final imgDir = Directory(p.join(dir.path, 'images'));
      if (!await imgDir.exists()) await imgDir.create(recursive: true);
      var ext = p.extension(x.path).toLowerCase();
      if (ext.isEmpty) ext = '.jpg';
      final dest = p.join(imgDir.path, '${const Uuid().v4()}$ext');
      await File(x.path).copy(dest);
      if (!mounted) return;
      setState(() => imagePath = dest);
    } catch (e) {
      snack('ছবি নেওয়া যায়নি।');
    }
  }

  void imageMenu() {
    showModalBottomSheet<void>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.photo_camera_rounded),
              title: const Text('ক্যামেরা দিয়ে ছবি তুলুন'),
              onTap: () {
                Navigator.pop(ctx);
                pickImage(ImageSource.camera);
              },
            ),
            ListTile(
              leading: const Icon(Icons.photo_library_rounded),
              title: const Text('গ্যালারি থেকে বাছুন'),
              onTap: () {
                Navigator.pop(ctx);
                pickImage(ImageSource.gallery);
              },
            ),
          ],
        ),
      ),
    );
  }

  // ---------- AI ----------

  Future<bool> runAi() async {
    final text = rawController.text.trim();
    if (text.isEmpty && imagePath == null) {
      snack('আগে কিছু লিখুন, বলুন বা ছবি দিন।');
      return false;
    }
    if (!SettingsService.instance.aiReady) {
      snack('AI চালু করতে আগে সেটিংসে API key দিন।');
      return false;
    }
    if (listening) {
      await voice.stop();
      if (mounted) setState(() => listening = false);
    }
    setState(() => aiBusy = true);
    try {
      final r = await AiService.instance.organize(text: text, imagePath: imagePath);
      if (!mounted) return false;
      setState(() {
        if (r.title.isNotEmpty) titleController.text = r.title;
        descriptionController.text = r.description;
        tagsController.text = r.tags.join(', ');
        category = r.category;
        repeat = r.repeat;
        if (r.reminder != null &&
            (r.reminder!.isAfter(DateTime.now()) || r.repeat != 'none')) {
          reminderDate = r.reminder;
        }
      });
      if (r.reminder != null) {
        snack('AI রিমাইন্ডার ঠিক করেছে: ${DateFormat('dd MMM, hh:mm a').format(r.reminder!)}');
      } else {
        snack('AI সাজিয়ে দিয়েছে। দেখে নিয়ে সংরক্ষণ করুন।');
      }
      return true;
    } on AiException catch (e) {
      snack(e.message);
      return false;
    } finally {
      if (mounted) setState(() => aiBusy = false);
    }
  }

  // ---------- reminder ----------

  Future<void> pickReminder() async {
    final now = DateTime.now();
    final initial = (reminderDate != null && reminderDate!.isAfter(now))
        ? reminderDate!
        : now.add(const Duration(hours: 1));
    final date = await showDatePicker(
      context: context,
      firstDate: DateTime(now.year, now.month, now.day),
      lastDate: DateTime(now.year + 20),
      initialDate: initial,
    );
    if (date == null || !mounted) return;
    final time = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.fromDateTime(initial),
    );
    if (time == null || !mounted) return;
    setState(() {
      reminderDate = DateTime(date.year, date.month, date.day, time.hour, time.minute);
    });
  }

  void quickReminder(DateTime d) => setState(() => reminderDate = d);

  // ---------- save ----------

  List<String> parseTags() => tagsController.text
      .split(RegExp(r'[,،]'))
      .map((t) => t.trim().replaceAll('#', ''))
      .where((t) => t.isNotEmpty)
      .toList();

  Future<void> save() async {
    final messenger = ScaffoldMessenger.of(context);

    if (titleController.text.trim().isEmpty) {
      final raw = rawController.text.trim();
      if (raw.isEmpty && imagePath == null) {
        snack('একটি বিষয় লিখুন।');
        return;
      }
      if (SettingsService.instance.aiReady) {
        await runAi();
      }
      if (!mounted) return;
      if (titleController.text.trim().isEmpty) {
        if (raw.isNotEmpty) {
          titleController.text = raw.length > 60 ? raw.substring(0, 60) : raw;
          if (raw.length > 60 && descriptionController.text.trim().isEmpty) {
            descriptionController.text = raw;
          }
        } else {
          titleController.text = 'ছবির স্মৃতি';
        }
      }
    }

    setState(() => saving = true);

    final e = widget.existing;
    final memory = Memory(
      id: e?.id ?? const Uuid().v4(),
      title: titleController.text.trim(),
      description: descriptionController.text.trim(),
      category: category,
      reminderDate: reminderDate,
      createdAt: e?.createdAt ?? DateTime.now(),
      repeat: reminderDate == null ? 'none' : repeat,
      tags: parseTags(),
      imagePath: imagePath,
      isDone: e?.isDone ?? false,
      isPinned: pinned,
    );

    if (editing) {
      await DatabaseService.instance.updateMemory(memory);
    } else {
      await DatabaseService.instance.insertMemory(memory);
    }

    String? warn;
    try {
      if (memory.reminderDate != null) {
        final granted = await NotificationService.instance.requestPermissions();
        if (!granted) {
          warn = 'নোটিফিকেশনের অনুমতি দেওয়া নেই, তাই রিমাইন্ডার বাজবে না। ফোনের সেটিংসে অনুমতি দিন।';
        }
      }
      await NotificationService.instance.schedule(memory);
    } catch (err) {
      warn = 'রিমাইন্ডার সেট করা যায়নি: $err';
    }

    if (warn != null) messenger.showSnackBar(SnackBar(content: Text(warn)));
    if (!mounted) return;
    Navigator.pop(context, true);
  }

  // ---------- UI ----------

  Widget quickChip(String label, DateTime d) => ActionChip(
        label: Text(label),
        onPressed: () => quickReminder(d),
      );

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final now = DateTime.now();
    final tonight = DateTime(now.year, now.month, now.day, 18, 0);
    final tomorrow9 = DateTime(now.year, now.month, now.day + 1, 9, 0);
    final aiReady = SettingsService.instance.aiReady;

    return Scaffold(
      appBar: AppBar(
        title: Text(editing ? 'স্মৃতি এডিট' : 'নতুন স্মৃতি'),
        actions: [
          IconButton(
            tooltip: pinned ? 'পিন সরান' : 'ওপরে পিন করুন',
            onPressed: () => setState(() => pinned = !pinned),
            icon: Icon(pinned ? Icons.push_pin_rounded : Icons.push_pin_outlined),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
        children: [
          if (!editing) ...[
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: scheme.primaryContainer,
                borderRadius: BorderRadius.circular(22),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.auto_awesome_rounded,
                          color: scheme.onPrimaryContainer),
                      const SizedBox(width: 8),
                      Text(
                        'বলুন, লিখুন বা ছবি দিন',
                        style: TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 16,
                          color: scheme.onPrimaryContainer,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: rawController,
                    minLines: 2,
                    maxLines: 6,
                    decoration: InputDecoration(
                      hintText: listening
                          ? 'শুনছি... বলুন'
                          : 'যেমন: কাল বিকেল ৫টায় রাকিবকে ৩০০০ টাকা ফেরত দিতে হবে',
                    ),
                  ),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      FilledButton.tonalIcon(
                        onPressed: toggleVoice,
                        icon: Icon(listening ? Icons.stop_rounded : Icons.mic_rounded),
                        label: Text(listening ? 'থামান' : 'ভয়েস'),
                        style: listening
                            ? FilledButton.styleFrom(
                                backgroundColor: scheme.errorContainer,
                                foregroundColor: scheme.onErrorContainer,
                              )
                            : null,
                      ),
                      FilledButton.tonalIcon(
                        onPressed: imageMenu,
                        icon: const Icon(Icons.add_photo_alternate_rounded),
                        label: const Text('ছবি'),
                      ),
                      FilledButton.icon(
                        onPressed: aiBusy ? null : runAi,
                        icon: aiBusy
                            ? const SizedBox(
                                width: 16,
                                height: 16,
                                child: CircularProgressIndicator(strokeWidth: 2),
                              )
                            : const Icon(Icons.auto_awesome_rounded),
                        label: Text(aiBusy ? 'সাজাচ্ছে...' : 'AI দিয়ে সাজান'),
                      ),
                    ],
                  ),
                  if (!aiReady)
                    Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Text(
                        'AI চালু করতে সেটিংসে API key দিন। এখন চাইলে হাতে লিখেও সংরক্ষণ করা যাবে।',
                        style: TextStyle(
                          fontSize: 12.5,
                          color: scheme.onPrimaryContainer,
                        ),
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 16),
          ] else
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Align(
                alignment: Alignment.centerLeft,
                child: OutlinedButton.icon(
                  onPressed: imageMenu,
                  icon: const Icon(Icons.add_photo_alternate_rounded),
                  label: Text(imagePath == null ? 'ছবি যোগ করুন' : 'ছবি বদলান'),
                ),
              ),
            ),
          if (imagePath != null && File(imagePath!).existsSync()) ...[
            Stack(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(18),
                  child: Image.file(
                    File(imagePath!),
                    height: 180,
                    width: double.infinity,
                    fit: BoxFit.cover,
                  ),
                ),
                Positioned(
                  top: 6,
                  right: 6,
                  child: IconButton.filledTonal(
                    onPressed: () => setState(() => imagePath = null),
                    icon: const Icon(Icons.close_rounded),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
          ],
          TextField(
            controller: titleController,
            textInputAction: TextInputAction.next,
            decoration: const InputDecoration(
              labelText: 'কী মনে রাখতে হবে?',
              prefixIcon: Icon(Icons.edit_note_rounded),
            ),
          ),
          const SizedBox(height: 14),
          TextField(
            controller: descriptionController,
            maxLines: 5,
            minLines: 3,
            decoration: const InputDecoration(
              labelText: 'বিস্তারিত',
              prefixIcon: Icon(Icons.notes_rounded),
              alignLabelWithHint: true,
            ),
          ),
          const SizedBox(height: 14),
          DropdownButtonFormField<String>(
            value: category,
            decoration: const InputDecoration(
              labelText: 'ধরন',
              prefixIcon: Icon(Icons.category_outlined),
            ),
            items: categoryLabels.entries
                .map((e) => DropdownMenuItem(value: e.key, child: Text(e.value)))
                .toList(),
            onChanged: (v) => setState(() => category = v ?? 'General'),
          ),
          const SizedBox(height: 14),
          TextField(
            controller: tagsController,
            decoration: const InputDecoration(
              labelText: 'ট্যাগ (কমা দিয়ে আলাদা করুন)',
              prefixIcon: Icon(Icons.tag_rounded),
            ),
          ),
          const SizedBox(height: 18),
          const Text(
            'রিমাইন্ডার',
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 4,
            children: [
              quickChip('১ ঘণ্টা পর', now.add(const Duration(hours: 1))),
              if (tonight.isAfter(now)) quickChip('আজ সন্ধ্যা ৬টা', tonight),
              quickChip('কাল সকাল ৯টা', tomorrow9),
            ],
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: pickReminder,
            icon: const Icon(Icons.calendar_month_rounded),
            label: Text(
              reminderDate == null
                  ? 'তারিখ ও সময় বাছুন'
                  : DateFormat('dd MMM yyyy, hh:mm a').format(reminderDate!),
            ),
          ),
          if (reminderDate != null) ...[
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: repeat,
                    decoration: const InputDecoration(
                      labelText: 'কতবার',
                      prefixIcon: Icon(Icons.repeat_rounded),
                    ),
                    items: repeatLabels.entries
                        .map((e) =>
                            DropdownMenuItem(value: e.key, child: Text(e.value)))
                        .toList(),
                    onChanged: (v) => setState(() => repeat = v ?? 'none'),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  tooltip: 'রিমাইন্ডার বাদ দিন',
                  onPressed: () => setState(() {
                    reminderDate = null;
                    repeat = 'none';
                  }),
                  icon: const Icon(Icons.alarm_off_rounded),
                ),
              ],
            ),
          ],
          const SizedBox(height: 26),
          FilledButton.icon(
            onPressed: (saving || aiBusy) ? null : save,
            icon: const Icon(Icons.check_rounded),
            label: Text(saving ? 'সংরক্ষণ হচ্ছে...' : (editing ? 'আপডেট করুন' : 'মনে রাখো')),
            style: FilledButton.styleFrom(
              minimumSize: const Size.fromHeight(54),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
