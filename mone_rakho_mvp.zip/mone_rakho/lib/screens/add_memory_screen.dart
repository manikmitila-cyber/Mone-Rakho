import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../models/memory.dart';
import '../services/database_service.dart';

class AddMemoryScreen extends StatefulWidget {
  const AddMemoryScreen({super.key});

  @override
  State<AddMemoryScreen> createState() => _AddMemoryScreenState();
}

class _AddMemoryScreenState extends State<AddMemoryScreen> {
  final titleController = TextEditingController();
  final descriptionController = TextEditingController();
  String category = 'General';
  DateTime? reminderDate;
  bool saving = false;

  @override
  void dispose() {
    titleController.dispose();
    descriptionController.dispose();
    super.dispose();
  }

  Future<void> save() async {
    if (titleController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('একটি বিষয় লিখুন।')),
      );
      return;
    }

    setState(() => saving = true);

    final memory = Memory(
      id: const Uuid().v4(),
      title: titleController.text.trim(),
      description: descriptionController.text.trim(),
      category: category,
      reminderDate: reminderDate,
      createdAt: DateTime.now(),
    );

    await DatabaseService.instance.insertMemory(memory);

    if (!mounted) return;
    Navigator.pop(context, true);
  }

  Future<void> pickDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      firstDate: now,
      lastDate: DateTime(now.year + 20),
      initialDate: now,
    );
    if (picked != null) {
      setState(() => reminderDate = picked);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('নতুন স্মৃতি')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          TextField(
            controller: titleController,
            textInputAction: TextInputAction.next,
            decoration: const InputDecoration(
              labelText: 'কী মনে রাখতে হবে?',
              hintText: 'যেমন: রাকিবকে ৩০০০ টাকা ধার দিলাম',
              prefixIcon: Icon(Icons.edit_note_rounded),
            ),
          ),
          const SizedBox(height: 14),
          TextField(
            controller: descriptionController,
            maxLines: 5,
            decoration: const InputDecoration(
              labelText: 'বিস্তারিত',
              hintText: 'অতিরিক্ত তথ্য লিখতে পারেন...',
              prefixIcon: Icon(Icons.notes_rounded),
              alignLabelWithHint: true,
            ),
          ),
          const SizedBox(height: 14),
          DropdownButtonFormField<String>(
            value: category,
            decoration: const InputDecoration(
              labelText: 'ধরন',
              prefixIcon: Icon(Icons.category_outlined),
            ),
            items: const [
              DropdownMenuItem(value: 'General', child: Text('সাধারণ')),
              DropdownMenuItem(value: 'Reminder', child: Text('রিমাইন্ডার')),
              DropdownMenuItem(value: 'Money', child: Text('টাকা-পয়সা')),
              DropdownMenuItem(value: 'Document', child: Text('ডকুমেন্ট')),
              DropdownMenuItem(value: 'Things', child: Text('কোথায় কী রেখেছি')),
            ],
            onChanged: (v) => setState(() => category = v!),
          ),
          const SizedBox(height: 14),
          OutlinedButton.icon(
            onPressed: pickDate,
            icon: const Icon(Icons.calendar_month_rounded),
            label: Text(
              reminderDate == null
                  ? 'রিমাইন্ডার তারিখ দিন'
                  : 'রিমাইন্ডার: ${reminderDate!.day}/${reminderDate!.month}/${reminderDate!.year}',
            ),
          ),
          const SizedBox(height: 24),
          FilledButton.icon(
            onPressed: saving ? null : save,
            icon: const Icon(Icons.check_rounded),
            label: Text(saving ? 'সংরক্ষণ হচ্ছে...' : 'মনে রাখো'),
            style: FilledButton.styleFrom(
              minimumSize: const Size.fromHeight(54),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
