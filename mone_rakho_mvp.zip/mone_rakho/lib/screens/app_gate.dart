import 'package:flutter/material.dart';
import '../services/lock_service.dart';
import '../services/settings_service.dart';
import 'home_screen.dart';

class AppGate extends StatefulWidget {
  const AppGate({super.key});

  @override
  State<AppGate> createState() => _AppGateState();
}

class _AppGateState extends State<AppGate> with WidgetsBindingObserver {
  bool locked = false;
  bool authenticating = false;
  DateTime? pausedAt;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    locked = SettingsService.instance.lockEnabled;
    if (locked) {
      WidgetsBinding.instance.addPostFrameCallback((_) => unlock());
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused) {
      pausedAt = DateTime.now();
    } else if (state == AppLifecycleState.resumed) {
      final p = pausedAt;
      if (p != null &&
          SettingsService.instance.lockEnabled &&
          !authenticating &&
          DateTime.now().difference(p).inSeconds > 60) {
        setState(() => locked = true);
        unlock();
      }
    }
  }

  Future<void> unlock() async {
    if (authenticating) return;
    authenticating = true;
    final ok = await LockService.instance
        .authenticate('"মনে রাখো" খুলতে নিজের পরিচয় নিশ্চিত করুন');
    authenticating = false;
    if (!mounted) return;
    if (ok) setState(() => locked = false);
  }

  @override
  Widget build(BuildContext context) {
    if (!locked) return const HomeScreen();
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.lock_rounded,
                  size: 64, color: Theme.of(context).colorScheme.primary),
              const SizedBox(height: 16),
              const Text(
                'মনে রাখো',
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 8),
              const Text('আপনার স্মৃতি সুরক্ষিত আছে।'),
              const SizedBox(height: 24),
              FilledButton.icon(
                onPressed: unlock,
                icon: const Icon(Icons.fingerprint_rounded),
                label: const Text('আনলক করুন'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
