import 'package:flutter/material.dart';

import '../models/memory.dart';
import '../services/ai_service.dart';
import '../services/database_service.dart';

class AskAiScreen extends StatefulWidget {
  const AskAiScreen({super.key});

  @override
  State<AskAiScreen> createState() => _AskAiScreenState();
}

class _QA {
  final String question;
  String? answer;
  bool error = false;
  _QA(this.question);
}

class _AskAiScreenState extends State<AskAiScreen> {
  final controller = TextEditingController();
  final scroll = ScrollController();
  final List<_QA> chat = [];
  List<Memory> memories = [];
  bool busy = false;

  static const suggestions = [
    'এই সপ্তাহে কী কী বাকি?',
    'কাকে কত টাকা দিয়েছি বা নিয়েছি?',
    'আমার ডকুমেন্টের তথ্য কী কী আছে?',
  ];

  @override
  void initState() {
    super.initState();
    DatabaseService.instance.getMemories().then((v) {
      if (mounted) setState(() => memories = v);
    });
  }

  @override
  void dispose() {
    controller.dispose();
    scroll.dispose();
    super.dispose();
  }

  Future<void> send([String? preset]) async {
    final q = (preset ?? controller.text).trim();
    if (q.isEmpty || busy) return;
    controller.clear();
    final qa = _QA(q);
    setState(() {
      chat.add(qa);
      busy = true;
    });
    _scrollDown();
    try {
      qa.answer = await AiService.instance.ask(q, memories);
    } on AiException catch (e) {
      qa.answer = e.message;
      qa.error = true;
    }
    if (!mounted) return;
    setState(() => busy = false);
    _scrollDown();
  }

  void _scrollDown() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (scroll.hasClients) {
        scroll.animateTo(
          scroll.position.maxScrollExtent + 200,
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('AI-কে জিজ্ঞেস করুন')),
      body: Column(
        children: [
          Expanded(
            child: chat.isEmpty
                ? ListView(
                    padding: const EdgeInsets.all(20),
                    children: [
                      Text(
                        'আপনার সংরক্ষিত স্মৃতি থেকে যেকোনো প্রশ্ন করুন।',
                        style: TextStyle(color: scheme.onSurfaceVariant),
                      ),
                      const SizedBox(height: 12),
                      ...suggestions.map(
                        (s) => Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: ActionChip(
                            label: Text(s),
                            onPressed: () => send(s),
                          ),
                        ),
                      ),
                    ],
                  )
                : ListView(
                    controller: scroll,
                    padding: const EdgeInsets.all(16),
                    children: chat
                        .expand((qa) => [
                              Align(
                                alignment: Alignment.centerRight,
                                child: Container(
                                  margin: const EdgeInsets.only(bottom: 8, left: 40),
                                  padding: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(
                                    color: scheme.primary,
                                    borderRadius: BorderRadius.circular(16),
                                  ),
                                  child: Text(
                                    qa.question,
                                    style: TextStyle(color: scheme.onPrimary),
                                  ),
                                ),
                              ),
                              Align(
                                alignment: Alignment.centerLeft,
                                child: Container(
                                  margin: const EdgeInsets.only(bottom: 14, right: 40),
                                  padding: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(
                                    color: qa.error
                                        ? scheme.errorContainer
                                        : scheme.surfaceContainerHighest,
                                    borderRadius: BorderRadius.circular(16),
                                  ),
                                  child: qa.answer == null
                                      ? const SizedBox(
                                          width: 18,
                                          height: 18,
                                          child: CircularProgressIndicator(strokeWidth: 2),
                                        )
                                      : SelectableText(qa.answer!),
                                ),
                              ),
                            ])
                        .toList(),
                  ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: controller,
                      minLines: 1,
                      maxLines: 4,
                      textInputAction: TextInputAction.send,
                      onSubmitted: (_) => send(),
                      decoration: const InputDecoration(hintText: 'প্রশ্ন লিখুন...'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton.filled(
                    onPressed: busy ? null : () => send(),
                    icon: const Icon(Icons.send_rounded),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
