import 'dart:io';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:share_plus/share_plus.dart';

import '../models/categories.dart';
import '../models/memory.dart';
import '../services/ai_service.dart';
import '../services/database_service.dart';
import '../services/notification_service.dart';
import '../services/settings_service.dart';
import '../widgets/memory_card.dart';
import 'add_memory_screen.dart';
import 'ask_ai_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Memory> memories = [];
  bool loading = true;
  bool rescheduled = false;
  String query = '';
  String filter = 'all';
  String? summary;
  bool summaryBusy = false;

  @override
  void initState() {
    super.initState();
    load();
    NotificationService.instance.requestPermissions().catchError((_) => true);
  }

  Future<void> load() async {
    final data = await DatabaseService.instance.getMemories();
    if (!mounted) return;
    setState(() {
      memories = data;
      loading = false;
    });
    if (!rescheduled) {
      rescheduled = true;
      NotificationService.instance.rescheduleAll(data);
    }
  }

  String get greeting {
    final h = DateTime.now().hour;
    if (h >= 5 && h < 12) return 'শুভ সকাল';
    if (h >= 12 && h < 15) return 'শুভ দুপুর';
    if (h >= 15 && h < 18) return 'শুভ বিকাল';
    if (h >= 18 && h < 20) return 'শুভ সন্ধ্যা';
    return 'শুভ রাত্রি';
  }

  List<Memory> get filtered {
    final q = query.trim().toLowerCase();
    final list = memories.where((m) {
      if (filter != 'all' && m.category != filter) return false;
      if (q.isEmpty) return true;
      return m.title.toLowerCase().contains(q) ||
          m.description.toLowerCase().contains(q) ||
          m.category.toLowerCase().contains(q) ||
          categoryLabel(m.category).contains(q) ||
          m.tags.any((t) => t.toLowerCase().contains(q));
    }).toList();
    list.sort((a, b) {
      if (a.isDone != b.isDone) return a.isDone ? 1 : -1;
      if (a.isPinned != b.isPinned) return a.isPinned ? -1 : 1;
      return b.createdAt.compareTo(a.createdAt);
    });
    return list;
  }

  Future<void> add({bool voice = false}) async {
    final result = await Navigator.push<bool>(
      context,
      MaterialPageRoute(builder: (_) => AddMemoryScreen(startVoice: voice)),
    );
    if (result == true) load();
  }

  Future<void> edit(Memory m) async {
    final result = await Navigator.push<bool>(
      context,
      MaterialPageRoute(builder: (_) => AddMemoryScreen(existing: m)),
    );
    if (result == true) load();
  }

  Future<void> toggleDone(Memory m) async {
    final updated = m.copyWith(isDone: !m.isDone);
    await DatabaseService.instance.updateMemory(updated);
    try {
      await NotificationService.instance.schedule(updated);
    } catch (_) {}
    load();
  }

  Future<void> togglePin(Memory m) async {
    await DatabaseService.instance.updateMemory(m.copyWith(isPinned: !m.isPinned));
    load();
  }

  Future<void> share(Memory m) async {
    final buf = StringBuffer(m.title);
    if (m.description.isNotEmpty) buf.write('\n${m.description}');
    if (m.reminderDate != null) {
      buf.write('\n⏰ ${DateFormat('dd MMM yyyy, hh:mm a').format(m.reminderDate!)}');
    }
    await Share.share(buf.toString());
  }

  Future<void> delete(Memory m) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('মুছে ফেলবেন?'),
        content: Text('"${m.title}" স্থায়ীভাবে মুছে যাবে।'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('না'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('মুছুন'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await NotificationService.instance.cancel(m.id);
    } catch (_) {}
    await DatabaseService.instance.deleteMemory(m.id);
    if (m.imagePath != null) {
      try {
        final f = File(m.imagePath!);
        if (await f.exists()) await f.delete();
      } catch (_) {}
    }
    load();
  }

  Future<void> openSettings() async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const SettingsScreen()),
    );
    if (mounted) setState(() {});
  }

  Future<void> runSummary() async {
    setState(() => summaryBusy = true);
    try {
      final s = await AiService.instance.summarize(memories);
      if (mounted) setState(() => summary = s);
    } on AiException catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
      }
    } finally {
      if (mounted) setState(() => summaryBusy = false);
    }
  }

  void showUpcoming() {
    final now = DateTime.now();
    final list = memories
        .where((m) =>
            m.reminderDate != null &&
            !m.isDone &&
            (m.reminderDate!.isAfter(now) || m.repeat != 'none'))
        .toList()
      ..sort((a, b) => a.reminderDate!.compareTo(b.reminderDate!));
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => SafeArea(
        child: ConstrainedBox(
          constraints: BoxConstraints(
            maxHeight: MediaQuery.of(context).size.height * 0.7,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Padding(
                padding: EdgeInsets.fromLTRB(20, 18, 20, 8),
                child: Text(
                  'আসন্ন রিমাইন্ডার',
                  style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800),
                ),
              ),
              if (list.isEmpty)
                const Padding(
                  padding: EdgeInsets.fromLTRB(20, 8, 20, 28),
                  child: Text('কোনো আসন্ন রিমাইন্ডার নেই।'),
                )
              else
                Flexible(
                  child: ListView(
                    shrinkWrap: true,
                    children: list
                        .map((m) => ListTile(
                              leading: const Icon(Icons.alarm_rounded),
                              title: Text(m.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                              subtitle: Text(
                                DateFormat('dd MMM yyyy, hh:mm a').format(m.reminderDate!) +
                                    (m.repeat != 'none' ? ' • ${repeatLabels[m.repeat]}' : ''),
                              ),
                              onTap: () {
                                Navigator.pop(ctx);
                                edit(m);
                              },
                            ))
                        .toList(),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget aiCard(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final ready = SettingsService.instance.aiReady;
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: scheme.primaryContainer,
        borderRadius: BorderRadius.circular(24),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.auto_awesome_rounded, color: scheme.onPrimaryContainer),
              const SizedBox(width: 8),
              Text(
                'AI সহকারী',
                style: TextStyle(
                  fontSize: 19,
                  fontWeight: FontWeight.w800,
                  color: scheme.onPrimaryContainer,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            summary ??
                (ready
                    ? 'লিখে, বলে বা ছবি দিয়ে সংরক্ষণ করুন। AI নিজে সাজিয়ে রিমাইন্ডার ঠিক করে দেবে, আর আপনার স্মৃতি থেকে প্রশ্নের উত্তরও দেবে।'
                    : 'AI চালু করতে সেটিংসে একটি API key দিন। তারপর AI আপনার কথা বুঝে নিজে সাজিয়ে রাখবে।'),
            style: TextStyle(color: scheme.onPrimaryContainer),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: ready
                ? [
                    FilledButton.icon(
                      onPressed: () => Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => const AskAiScreen()),
                      ),
                      icon: const Icon(Icons.chat_bubble_outline_rounded),
                      label: const Text('জিজ্ঞেস করুন'),
                    ),
                    FilledButton.tonalIcon(
                      onPressed: summaryBusy ? null : runSummary,
                      icon: summaryBusy
                          ? const SizedBox(
                              width: 16,
                              height: 16,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Icon(Icons.wb_sunny_outlined),
                      label: Text(summaryBusy ? 'লিখছে...' : 'আজকের সারসংক্ষেপ'),
                    ),
                  ]
                : [
                    FilledButton.icon(
                      onPressed: openSettings,
                      icon: const Icon(Icons.key_rounded),
                      label: const Text('AI চালু করুন'),
                    ),
                  ],
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final items = filtered;
    final scheme = Theme.of(context).colorScheme;

    return Scaffold(
      appBar: AppBar(
        title: const Text('মনে রাখো', style: TextStyle(fontWeight: FontWeight.w800)),
        actions: [
          IconButton(
            tooltip: 'আসন্ন রিমাইন্ডার',
            onPressed: showUpcoming,
            icon: const Icon(Icons.notifications_none_rounded),
          ),
          IconButton(
            tooltip: 'সেটিংস',
            onPressed: openSettings,
            icon: const Icon(Icons.settings_outlined),
          ),
          const SizedBox(width: 4),
        ],
      ),
      floatingActionButton: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          FloatingActionButton.small(
            heroTag: 'mic',
            tooltip: 'ভয়েসে বলুন',
            onPressed: () => add(voice: true),
            child: const Icon(Icons.mic_rounded),
          ),
          const SizedBox(height: 12),
          FloatingActionButton.extended(
            heroTag: 'add',
            onPressed: () => add(),
            icon: const Icon(Icons.add_rounded),
            label: const Text('মনে রাখো'),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: load,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 140),
          children: [
            Text(
              '$greeting 👋',
              style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 5),
            Text(
              'আপনি ভুলে গেলেও, এটা ভুলবে না।',
              style: TextStyle(color: scheme.onSurfaceVariant, fontSize: 15),
            ),
            const SizedBox(height: 18),
            TextField(
              onChanged: (v) => setState(() => query = v),
              decoration: const InputDecoration(
                hintText: 'আপনার স্মৃতিতে খুঁজুন...',
                prefixIcon: Icon(Icons.search_rounded),
              ),
            ),
            const SizedBox(height: 16),
            aiCard(context),
            const SizedBox(height: 20),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ChoiceChip(
                      label: const Text('সব'),
                      selected: filter == 'all',
                      onSelected: (_) => setState(() => filter = 'all'),
                    ),
                  ),
                  ...categoryLabels.entries.map(
                    (e) => Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: ChoiceChip(
                        label: Text(e.value),
                        selected: filter == e.key,
                        onSelected: (_) => setState(() => filter = e.key),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'সাম্প্রতিক স্মৃতি',
                  style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800),
                ),
                Text('${items.length}টি'),
              ],
            ),
            const SizedBox(height: 12),
            if (loading)
              const Padding(
                padding: EdgeInsets.all(30),
                child: Center(child: CircularProgressIndicator()),
              )
            else if (items.isEmpty)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(30),
                  child: Column(
                    children: [
                      Icon(Icons.psychology_alt_outlined,
                          size: 52, color: scheme.outline),
                      const SizedBox(height: 12),
                      const Text(
                        'এখনও কোনো স্মৃতি নেই।',
                        style: TextStyle(fontWeight: FontWeight.w700),
                      ),
                      const SizedBox(height: 5),
                      const Text(
                        'নিচের “মনে রাখো” বা মাইক বাটনে চাপ দিয়ে প্রথম স্মৃতিটি যোগ করুন।',
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              )
            else
              ...items.map(
                (m) => Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: MemoryCard(
                    memory: m,
                    onTap: () => edit(m),
                    onToggleDone: () => toggleDone(m),
                    onTogglePin: () => togglePin(m),
                    onShare: () => share(m),
                    onDelete: () => delete(m),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
