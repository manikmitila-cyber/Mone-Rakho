import 'package:flutter/material.dart';
import '../models/memory.dart';
import '../services/database_service.dart';
import '../widgets/memory_card.dart';
import 'add_memory_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Memory> memories = [];
  bool loading = true;
  String query = '';

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final data = await DatabaseService.instance.getMemories();
    if (!mounted) return;
    setState(() {
      memories = data;
      loading = false;
    });
  }

  List<Memory> get filtered {
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return memories;
    return memories.where((m) {
      return m.title.toLowerCase().contains(q) ||
          m.description.toLowerCase().contains(q) ||
          m.category.toLowerCase().contains(q);
    }).toList();
  }

  Future<void> add() async {
    final result = await Navigator.push<bool>(
      context,
      MaterialPageRoute(builder: (_) => const AddMemoryScreen()),
    );
    if (result == true) load();
  }

  Future<void> delete(Memory memory) async {
    await DatabaseService.instance.deleteMemory(memory.id);
    load();
  }

  @override
  Widget build(BuildContext context) {
    final items = filtered;

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'মনে রাখো',
          style: TextStyle(fontWeight: FontWeight.w800),
        ),
        actions: [
          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.notifications_none_rounded),
          ),
          const SizedBox(width: 6),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: add,
        icon: const Icon(Icons.add_rounded),
        label: const Text('মনে রাখো'),
      ),
      body: RefreshIndicator(
        onRefresh: load,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 100),
          children: [
            const Text(
              'শুভ সকাল 👋',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 5),
            Text(
              'আপনি ভুলে গেলেও, এটা ভুলবে না।',
              style: TextStyle(
                color: Colors.grey.shade700,
                fontSize: 15,
              ),
            ),
            const SizedBox(height: 18),
            TextField(
              onChanged: (v) => setState(() => query = v),
              decoration: const InputDecoration(
                hintText: 'আপনার স্মৃতিতে খুঁজুন...',
                prefixIcon: Icon(Icons.search_rounded),
              ),
            ),
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Theme.of(context)
                    .colorScheme
                    .primaryContainer,
                borderRadius: BorderRadius.circular(24),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.auto_awesome_rounded, size: 28),
                  SizedBox(height: 12),
                  Text(
                    'কী মনে রাখতে হবে?',
                    style: TextStyle(
                      fontSize: 21,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  SizedBox(height: 5),
                  Text(
                    'এখন লিখে সংরক্ষণ করুন। পরের ধাপে AI আপনার কথাই বুঝে নিজে থেকে সাজিয়ে রাখবে।',
                  ),
                ],
              ),
            ),
            const SizedBox(height: 26),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'সাম্প্রতিক স্মৃতি',
                  style: TextStyle(
                    fontSize: 19,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                Text('${items.length}টি'),
              ],
            ),
            const SizedBox(height: 12),
            if (loading)
              const Padding(
                padding: EdgeInsets.all(30),
                child: Center(child: CircularProgressIndicator()),
              )
            else if (items.isEmpty)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(30),
                  child: Column(
                    children: [
                      Icon(
                        Icons.psychology_alt_outlined,
                        size: 52,
                        color: Colors.grey.shade500,
                      ),
                      const SizedBox(height: 12),
                      const Text(
                        'এখনও কোনো স্মৃতি নেই।',
                        style: TextStyle(fontWeight: FontWeight.w700),
                      ),
                      const SizedBox(height: 5),
                      const Text(
                        'নিচের “মনে রাখো” বাটনে চাপ দিয়ে প্রথম স্মৃতিটি যোগ করুন।',
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
              )
            else
              ...items.map(
                (memory) => Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: MemoryCard(
                    memory: memory,
                    onDelete: () => delete(memory),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
