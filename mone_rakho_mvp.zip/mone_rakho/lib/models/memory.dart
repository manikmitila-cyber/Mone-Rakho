class Memory {
  final String id;
  final String title;
  final String description;
  final String category;
  final DateTime? reminderDate;
  final DateTime createdAt;

  const Memory({
    required this.id,
    required this.title,
    required this.description,
    required this.category,
    this.reminderDate,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'title': title,
        'description': description,
        'category': category,
        'reminderDate': reminderDate?.millisecondsSinceEpoch,
        'createdAt': createdAt.millisecondsSinceEpoch,
      };

  factory Memory.fromMap(Map<String, dynamic> map) => Memory(
        id: map['id'] as String,
        title: map['title'] as String,
        description: (map['description'] ?? '') as String,
        category: map['category'] as String,
        reminderDate: map['reminderDate'] == null
            ? null
            : DateTime.fromMillisecondsSinceEpoch(
                map['reminderDate'] as int,
              ),
        createdAt: DateTime.fromMillisecondsSinceEpoch(
          map['createdAt'] as int,
        ),
      );
}
