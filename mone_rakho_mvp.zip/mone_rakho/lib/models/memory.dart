import 'dart:convert';

class Memory {
  final String id;
  final String title;
  final String description;
  final String category;
  final DateTime? reminderDate;
  final DateTime createdAt;
  final String repeat; // none, daily, weekly, monthly
  final List<String> tags;
  final String? imagePath;
  final bool isDone;
  final bool isPinned;

  const Memory({
    required this.id,
    required this.title,
    required this.description,
    required this.category,
    this.reminderDate,
    required this.createdAt,
    this.repeat = 'none',
    this.tags = const [],
    this.imagePath,
    this.isDone = false,
    this.isPinned = false,
  });

  Memory copyWith({bool? isDone, bool? isPinned}) => Memory(
        id: id,
        title: title,
        description: description,
        category: category,
        reminderDate: reminderDate,
        createdAt: createdAt,
        repeat: repeat,
        tags: tags,
        imagePath: imagePath,
        isDone: isDone ?? this.isDone,
        isPinned: isPinned ?? this.isPinned,
      );

  Map<String, dynamic> toMap() => {
        'id': id,
        'title': title,
        'description': description,
        'category': category,
        'reminderDate': reminderDate?.millisecondsSinceEpoch,
        'createdAt': createdAt.millisecondsSinceEpoch,
        'repeatRule': repeat,
        'tags': jsonEncode(tags),
        'imagePath': imagePath,
        'isDone': isDone ? 1 : 0,
        'isPinned': isPinned ? 1 : 0,
      };

  factory Memory.fromMap(Map<String, dynamic> map) {
    List<String> tags = [];
    try {
      final raw = map['tags'];
      if (raw is String && raw.isNotEmpty) {
        tags = (jsonDecode(raw) as List).map((e) => e.toString()).toList();
      }
    } catch (_) {}
    return Memory(
      id: map['id'] as String,
      title: map['title'] as String,
      description: (map['description'] ?? '') as String,
      category: (map['category'] ?? 'General') as String,
      reminderDate: map['reminderDate'] == null
          ? null
          : DateTime.fromMillisecondsSinceEpoch(map['reminderDate'] as int),
      createdAt: DateTime.fromMillisecondsSinceEpoch(map['createdAt'] as int),
      repeat: (map['repeatRule'] ?? 'none') as String,
      tags: tags,
      imagePath: map['imagePath'] as String?,
      isDone: ((map['isDone'] ?? 0) as int) == 1,
      isPinned: ((map['isPinned'] ?? 0) as int) == 1,
    );
  }
}
