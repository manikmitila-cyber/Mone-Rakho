import 'package:flutter/material.dart';

const Map<String, String> categoryLabels = {
  'General': 'সাধারণ',
  'Reminder': 'রিমাইন্ডার',
  'Money': 'টাকা-পয়সা',
  'Document': 'ডকুমেন্ট',
  'Things': 'কোথায় কী রেখেছি',
  'Health': 'স্বাস্থ্য',
};

const Map<String, String> repeatLabels = {
  'none': 'একবার',
  'daily': 'প্রতিদিন',
  'weekly': 'প্রতি সপ্তাহে',
  'monthly': 'প্রতি মাসে',
};

String categoryLabel(String c) => categoryLabels[c] ?? categoryLabels['General']!;

IconData categoryIcon(String c) {
  switch (c) {
    case 'Reminder':
      return Icons.alarm_rounded;
    case 'Money':
      return Icons.payments_rounded;
    case 'Document':
      return Icons.description_rounded;
    case 'Things':
      return Icons.location_on_rounded;
    case 'Health':
      return Icons.favorite_rounded;
    default:
      return Icons.lightbulb_rounded;
  }
}
