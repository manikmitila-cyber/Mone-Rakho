import 'dart:io';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/categories.dart';
import '../models/memory.dart';

class MemoryCard extends StatelessWidget {
  final Memory memory;
  final VoidCallback onTap;
  final VoidCallback onToggleDone;
  final VoidCallback onTogglePin;
  final VoidCallback onShare;
  final VoidCallback onDelete;

  const MemoryCard({
    super.key,
    required this.memory,
    required this.onTap,
    required this.onToggleDone,
    required this.onTogglePin,
    required this.onShare,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final m = memory;
    final muted = scheme.onSurfaceVariant;
    final overdue = m.reminderDate != null &&
        !m.isDone &&
        m.repeat == 'none' &&
        m.reminderDate!.isBefore(DateTime.now());

    Widget leading;
    if (m.imagePath != null && File(m.imagePath!).existsSync()) {
      leading = ClipRRect(
        borderRadius: BorderRadius.circular(14),
        child: Image.file(
          File(m.imagePath!),
          width: 52,
          height: 52,
          fit: BoxFit.cover,
          errorBuilder: (_, __, ___) => const SizedBox(width: 52, height: 52),
        ),
      );
    } else {
      leading = CircleAvatar(
        radius: 26,
        backgroundColor: scheme.primaryContainer,
        child: Icon(categoryIcon(m.category), color: scheme.onPrimaryContainer),
      );
    }

    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14, 12, 4, 12),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              leading,
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        if (m.isPinned)
                          Padding(
                            padding: const EdgeInsets.only(right: 4),
                            child: Icon(Icons.push_pin_rounded,
                                size: 15, color: scheme.primary),
                          ),
                        Expanded(
                          child: Text(
                            m.title,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 15.5,
                              decoration:
                                  m.isDone ? TextDecoration.lineThrough : null,
                              color: m.isDone ? muted : null,
                            ),
                          ),
                        ),
                      ],
                    ),
                    if (m.description.isNotEmpty) ...[
                      const SizedBox(height: 4),
                      Text(
                        m.description,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(color: muted, fontSize: 13.5),
                      ),
                    ],
                    const SizedBox(height: 6),
                    Wrap(
                      spacing: 8,
                      runSpacing: 4,
                      crossAxisAlignment: WrapCrossAlignment.center,
                      children: [
                        Text(
                          '${categoryLabel(m.category)} • ${DateFormat('dd MMM yyyy').format(m.createdAt)}',
                          style: TextStyle(fontSize: 12, color: muted),
                        ),
                        if (m.reminderDate != null)
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                Icons.alarm_rounded,
                                size: 14,
                                color: overdue ? scheme.error : scheme.primary,
                              ),
                              const SizedBox(width: 3),
                              Text(
                                DateFormat('dd MMM, hh:mm a')
                                        .format(m.reminderDate!) +
                                    (m.repeat != 'none'
                                        ? ' • ${repeatLabels[m.repeat]}'
                                        : ''),
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                  color:
                                      overdue ? scheme.error : scheme.primary,
                                ),
                              ),
                            ],
                          ),
                      ],
                    ),
                    if (m.tags.isNotEmpty) ...[
                      const SizedBox(height: 4),
                      Text(
                        m.tags.map((t) => '#$t').join('  '),
                        style: TextStyle(fontSize: 12, color: scheme.tertiary),
                      ),
                    ],
                  ],
                ),
              ),
              PopupMenuButton<String>(
                icon: const Icon(Icons.more_vert_rounded),
                onSelected: (v) {
                  switch (v) {
                    case 'done':
                      onToggleDone();
                      break;
                    case 'pin':
                      onTogglePin();
                      break;
                    case 'share':
                      onShare();
                      break;
                    case 'delete':
                      onDelete();
                      break;
                    case 'edit':
                      onTap();
                      break;
                  }
                },
                itemBuilder: (_) => [
                  PopupMenuItem(
                    value: 'done',
                    child: Text(m.isDone ? 'আবার বাকি করুন' : 'সম্পন্ন করুন'),
                  ),
                  PopupMenuItem(
                    value: 'pin',
                    child: Text(m.isPinned ? 'পিন সরান' : 'ওপরে পিন করুন'),
                  ),
                  const PopupMenuItem(value: 'edit', child: Text('এডিট করুন')),
                  const PopupMenuItem(value: 'share', child: Text('শেয়ার করুন')),
                  const PopupMenuItem(value: 'delete', child: Text('মুছে ফেলুন')),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
