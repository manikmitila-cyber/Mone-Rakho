# মনে রাখো — Mone Rakho

একটি Flutter MVP: personal memory app.

## প্রথমে যা লাগবে
- Flutter SDK
- Android Studio
- Android SDK
- Android emulator অথবা USB debugging চালু করা Android ফোন

## রান করার ধাপ

```bash
flutter doctor
flutter pub get
flutter run
```

Android Studio ব্যবহার করলে:
1. ZIP extract করুন।
2. Android Studio → Open → `mone_rakho` folder নির্বাচন করুন।
3. Terminal খুলে `flutter pub get` চালান।
4. Emulator/Android ফোন চালু করুন।
5. Run ▶ চাপুন।

## এই MVP-তে আছে
- Home
- Add Memory
- Memory list
- Category
- Local SQLite database
- Delete memory
- Search
- Settings placeholder

## পরের ধাপ
Reminder → Bangla voice → AI parsing → OCR → Money tracking → Documents → Cloud backup → Family mode.
