#!/usr/bin/env python3
"""flutter create-এর পর Android ফাইলে দরকারি অনুমতি ও সেটিংস বসায়।"""
import glob
import os
import re
import sys


def read(path):
    with open(path, encoding="utf-8") as f:
        return f.read()


def write(path, text):
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)


def fail(msg):
    print("PATCH ERROR:", msg)
    sys.exit(1)


# ---------- AndroidManifest ----------
mp = "android/app/src/main/AndroidManifest.xml"
if not os.path.exists(mp):
    fail("AndroidManifest.xml পাওয়া যায়নি")
m = read(mp)

permissions = [
    "android.permission.INTERNET",
    "android.permission.POST_NOTIFICATIONS",
    "android.permission.RECEIVE_BOOT_COMPLETED",
    "android.permission.VIBRATE",
    "android.permission.WAKE_LOCK",
    "android.permission.SCHEDULE_EXACT_ALARM",
    "android.permission.USE_EXACT_ALARM",
    "android.permission.RECORD_AUDIO",
    "android.permission.BLUETOOTH",
    "android.permission.BLUETOOTH_ADMIN",
    "android.permission.BLUETOOTH_CONNECT",
    "android.permission.USE_BIOMETRIC",
]
lines = "".join(
    '    <uses-permission android:name="%s"/>\n' % p
    for p in permissions
    if ('"%s"' % p) not in m
)
if lines:
    m = re.sub(r"(<manifest[^>]*>)", lambda mo: mo.group(1) + "\n" + lines, m, count=1)

receivers = """
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver" />
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED"/>
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED"/>
                <action android:name="android.intent.action.QUICKBOOT_POWERON" />
                <action android:name="com.htc.intent.action.QUICKBOOT_POWERON"/>
            </intent-filter>
        </receiver>
"""
if "ScheduledNotificationReceiver" not in m:
    m = m.replace("</application>", receivers + "    </application>", 1)

queries = """
    <queries>
        <intent>
            <action android:name="android.speech.RecognitionService"/>
        </intent>
    </queries>
"""
if "android.speech.RecognitionService" not in m:
    m = m.replace("</manifest>", queries + "</manifest>", 1)

m = m.replace('android:label="mone_rakho"', 'android:label="মনে রাখো"')
write(mp, m)

# ---------- Gradle ----------
gp = None
for cand in ("android/app/build.gradle.kts", "android/app/build.gradle"):
    if os.path.exists(cand):
        gp = cand
        break
if gp is None:
    fail("android/app/build.gradle(.kts) পাওয়া যায়নি")
g = read(gp)

if gp.endswith(".kts"):
    if "isCoreLibraryDesugaringEnabled" not in g:
        g = g.replace(
            "compileOptions {",
            "compileOptions {\n        isCoreLibraryDesugaringEnabled = true",
            1,
        )
    g = re.sub(r"minSdk\s*=\s*flutter\.minSdkVersion", "minSdk = 24", g)
    if "isMinifyEnabled" not in g:
        g = re.sub(
            r"(buildTypes\s*\{\s*(?:getByName\(\"release\"\)|release)\s*\{)",
            r"\1\n            isMinifyEnabled = false\n            isShrinkResources = false",
            g,
            count=1,
        )
    if "coreLibraryDesugaring(" not in g:
        g += (
            "\ndependencies {\n"
            '    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")\n'
            "}\n"
        )
    ok = (
        "isCoreLibraryDesugaringEnabled = true" in g
        and "coreLibraryDesugaring(" in g
        and "minSdk = 24" in g
        and "isMinifyEnabled = false" in g
    )
else:
    if "coreLibraryDesugaringEnabled" not in g:
        g = g.replace(
            "compileOptions {",
            "compileOptions {\n        coreLibraryDesugaringEnabled true",
            1,
        )
    g = re.sub(r"minSdk(?:Version)?\s*=?\s*flutter\.minSdkVersion", "minSdkVersion 24", g)
    if "minifyEnabled" not in g:
        g = re.sub(
            r"(buildTypes\s*\{\s*release\s*\{)",
            r"\1\n            minifyEnabled false\n            shrinkResources false",
            g,
            count=1,
        )
    if "coreLibraryDesugaring '" not in g:
        g += (
            "\ndependencies {\n"
            "    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.4'\n"
            "}\n"
        )
    ok = (
        "coreLibraryDesugaringEnabled true" in g
        and "coreLibraryDesugaring '" in g
        and "minSdkVersion 24" in g
        and "minifyEnabled false" in g
    )
if not ok:
    print(g)
    fail("%s প্যাচ পুরোপুরি হয়নি (উপরে ফাইলটি দেখুন)" % gp)
write(gp, g)

# ---------- MainActivity (local_auth-এর জন্য FragmentActivity) ----------
acts = glob.glob("android/app/src/main/**/MainActivity.*", recursive=True)
if not acts:
    fail("MainActivity পাওয়া যায়নি")
for a in acts:
    t = read(a)
    if "FlutterFragmentActivity" not in t:
        write(a, t.replace("FlutterActivity", "FlutterFragmentActivity"))

print("Android প্যাচ সম্পন্ন:", gp)
